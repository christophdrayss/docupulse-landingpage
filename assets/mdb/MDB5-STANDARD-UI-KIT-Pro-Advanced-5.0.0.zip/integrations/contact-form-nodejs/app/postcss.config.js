module.exports = () => ({
  plugins: {
    autoprefixer: {}
  }
})